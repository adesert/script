#!/bin/bash

source config.sh $1


#remove old files
if [ $1 -le 1 -o $1 -eq 998 -o $1 -eq 999 ];then
 echo "开始删除旧文件，创建新文件"
 CMD="cd $appHome/onstage && rm -rf * && cp ../$zipfile . && unzip $zipfile"
 ssh -f ${user}@${serverIp} "$CMD" >> /tmp/gameServer_ssh_log || (echo "Init command could not remove files on $serverIp" && exit 1)

 sleep 20
fi

base=${srcroot}

libs="${base}/lib/*"

classPath="classes"
classPath="$classPath:$libs"

options="-server -Druntime.env=$runTimeEnv -Dapp.home=$appHome -Dapp.startDate=$startDate -Dfile.encoding=UTF8 -Dlog4j.configuration=StageServerLog4j.properties -Dio.netty.leakDetectionLevel=advanced"
options="$options -XX:+HeapDumpOnOutOfMemoryError -XX:-OmitStackTraceInFastThrow"

CMD="PATH=${javaHome}/bin:/usr/local/bin:/bin:/usr/bin export PATH; JAVA_HOME=${javaHome}; export JAVA_HOME; cd ${srcroot} && java $options -mx$conMxSize -cp \"${classPath}\" com.play.main.Main > /dev/null < /dev/null 2>>~/error_log.txt &"
echo "开始启动服务器"
ssh -f ${user}@${serverIp} "${CMD}" >> /tmp/gameServer_ssh_log || (echo "Init command could not start on $machine" && exit 1)
echo "启动服务器结束"

# sleep 15
# echo "http://$webUrl/gm/rewardMailScript/gmRewardsxLzUCavq3Zou61?isReward=1"
# wget -q "http://$webUrl/gm/rewardMailScript/gmRewardsxLzUCavq3Zou61?isReward=1"
# echo $(cat gmRewardsxLzUCavq3Zou61)
# echo "发奖结束"
#rm -rf gmRewardsxLzUCavq3Zou61

exit 0

