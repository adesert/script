./kick.sh 998
./stop.sh 998
./start.sh 998
