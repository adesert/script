	#!/bin/bash
# atw wuz her

source config.sh $1
echo "开始踢人"
isConUp "http://$webUrl/kick/kickxLzUCu63avq3Zoss"
sleep 1
echo " kick all players successful on server $runtimeEnv"

