	#!/bin/bash
# atw wuz her

source config.sh $1

#uncomment the following if we need to force kill all java processes.
#CMD="killall -v java && sleep 4 && killall -9 java"

# atw - I'm changing it to use ps because jps is unreliable sometimes
#ps -ef | grep "com.play.main" | grep -v "grep" | grep -v "bash"

CMD="jotpids() { ps -ef | grep "com.play.main.Main" | grep $runTimeEnv | grep -v "grep" | grep -v "bash" | awk '{print \\\$2}'; }; \
for pid in \\\`jotpids\\\`; do echo killing ballistics app on \\\`hostname\\\` pid \\\$pid; if [ \\\"$BALLI_JSTACK_BEFORE_STOP\\\" != \\\"\\\" ]; then jps -lm | grep \\\$pid; jstack \\\$pid; fi; kill \\\$pid; done; sleep 6; for pid in \\\`jotpids\\\`; do kill -9 \\\$pid; done"

echo "Stopping all java." $CMD
#ssh ${user}@$sss "bash -c \"jps -l\"" || (echo "Init command could not kill java on ${sss}" && exit 1);
ssh -i ${sshkey} ${user}@${serverIp} "bash -c \"$CMD\"" || (echo "stop.sh could not kill java on ${serverIp}" && exit 1);

echo "停止了游戏进程"

sleep 2

