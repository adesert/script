./kick.sh 999
./stop.sh 999
./start.sh 999
