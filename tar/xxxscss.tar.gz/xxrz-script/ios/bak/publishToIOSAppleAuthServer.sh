scp /data/soft/NS/N_RuT0/publish/package/backend.zip 112.126.85.107:/data
