#!/bin/bash
#upload all server resource
IFS=$'\r\n'
serversIP=([0]='112.126.85.108' [1]='112.126.84.159' [2]='112.126.84.186')
for ((i=0; i<3; ++i));
do
    echo ${serversIP:$i}
done
