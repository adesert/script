#!/bin/bash

source config.sh $1

scp /data/soft/NS/N_RuT0/publish/package/backend.zip $serverIp:/data

#remove old files
if [ $1 -le 6 -o $1 -eq 999 ];then
 echo "开始删除旧文件，创建新文件"
 CMD="cd $appHome/onstage && rm -rf * && cp ../$zipfile . && unzip -q -o $zipfile"
 ssh -f ${user}@${serverIp} "$CMD" >> /tmp/gameServer_ssh_log || (echo "Init command could not remove files on $serverIp" && exit 1)
 sleep 10
fi
