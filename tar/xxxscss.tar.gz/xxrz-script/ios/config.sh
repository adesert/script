#!/bin/bash

serversFile="serverList.txt"

contactPort="80"
#srcroot="/root"
srcroot=/data/onstage/nadron
sshkey=/root/.ssh/id_rsa
userkey=/Users/appo/.ssh/id_rsa
user=root
javaHome=/usr/lib/jvm/java-1.6.0-openjdk-1.6.0.0.x86_64/
appHome=/data
env="i"
webUrl=""
webPort="8082"


centerIp="180.150.178.51"
gitroot=/data/soft/NS/N_RuT0
packageroot="$gitroot/publish/package"
zipfile="backend.zip"

echo "pachage root $packageroot $zipfile"
IFS=$'\r\n'
if [ "$1" = "" ];
then
    echo "need to specify user"
    exit
else
      for server in `cat ${serversFile}`;
      do
         if [ "$1" = `echo $server | awk '{ print $1 }'` ];
         then
         serverIp=`echo $server | awk '{ print $2 }'`
         contactPort=`echo $server | awk '{ print $3 }'`
         conMxSize=`echo $server | awk '{ print $4 }'`
         logMxSize=`echo $server | awk '{ print $5 }'` 
         startDate=`echo $server | awk '{ print $6 }'` 
         webPort=`echo $server | awk '{ print $8 }'` 
         runTimeEnv="$env-$1"    
         webUrl="$serverIp:$webPort"   
	     echo "$runTimeEnv $webUrl"
         fi
      done
fi

isConUp() {
    count=0
    url=${1?You have not included a url to check for start up in the isConIp function}  
    start_ts=`date +%s`
    dropdead_ts=$[start_ts + MAX_SECS_TO_WAIT]
    #echo "start_ts: $start_ts, drop dead stamp: $dropdead_ts"
    while [ true ];
    do
        current_ts=`date +%s`
        if [ "$current_ts" -gt "$dropdead_ts" ];
        then
            echo "Could not verify $url" && exit 1
        fi  
        echo "`date` : **********URL: $url"
        output=`curl --connect-timeout 3 --max-time 5 $url`
        echo $output
        [ "$output" = "OK" ] && break 1
        count=$[count + 1]
        echo "attempt # $count for $url"
        sleep 1 
    done
}

