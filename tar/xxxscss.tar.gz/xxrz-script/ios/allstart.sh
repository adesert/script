#!/bin/bash
#start all server
IFS=$'\r\n'
serversFile="serverList.txt"
for server in `cat ${serversFile}`;
do
        declare target=`echo $server | awk '{ print $1 }'`
        ./start.sh ${target}
	sleep 15
done
exit 0
