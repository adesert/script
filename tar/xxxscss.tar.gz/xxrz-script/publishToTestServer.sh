scp /data/soft/NS/N_RuT0/publish/package/backend.zip 123.56.245.100:/data/
