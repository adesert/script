#!/bin/bash
#stop all server
serversFile="serverList.txt"
IFS=$'\r\n'
for server in `cat ${serversFile}`;
do
        declare target=`echo $server | awk '{ print $1 }'`
        echo $target
       ./kick.sh ${target}
done
