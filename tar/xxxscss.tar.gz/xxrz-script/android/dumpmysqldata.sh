#!/bin/bash
#stop all server
serversFile="serverList.txt"
qote="_"
IFS=$'\r\n'
for server in `cat ${serversFile}`;
do
	declare target=`echo $server | awk '{ print $1 }'`
	declare serverIp=`echo $server | awk '{ print $2 }'`
        sqldump=balli$target$qote`date +%u`.sql
        CMD="mysqldump -uroot -p'dre@mJ$11y' balli$target > /data/databackup/$sqldump"
        #sh -f ${user}@${serverIp} "${CMD}" >> /tmp/gameServer_dump_sql_ssh_log || (echo "Fail on $server" && exit 1)
        echo $CMD
done
