#!/bin/bash
#stop all server
serversFile="serverList.txt"
IFS=$'\r\n'
size=0
for server in `cat ${serversFile}`;
do

 		size=$size+1
        # declare target=`echo $server | awk '{ print $1 }'`
        # ./stop.sh ${target}
done
for((i=size-1;i>=1;i--))
do
	echo $i
    ./stop.sh ${i}
done