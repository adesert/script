#!/bin/bash

source config.sh 999

cd $gitroot && git pull && echo pull over && sleep 1 && ant -buildfile mybuild.xml  && echo ant over

