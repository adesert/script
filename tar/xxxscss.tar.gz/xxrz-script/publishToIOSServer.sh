scp /data/soft/NS/N_RuT0/publish/package/backend.zip 123.57.13.252:/data/
